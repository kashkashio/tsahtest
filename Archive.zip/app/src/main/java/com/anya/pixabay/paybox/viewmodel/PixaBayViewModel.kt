package com.anya.pixabay.paybox.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.anya.pixabay.paybox.data.OperationCallback
import com.anya.pixabay.paybox.model.Hit
import com.anya.pixabay.paybox.model.PixaBayDataSource

class PixaBayViewModel(private val repository: PixaBayDataSource) : ViewModel() {

    private val _museums = MutableLiveData<List<Hit>>().apply { value = emptyList() }
    val museums: LiveData<List<Hit>> = _museums

    private val _isViewLoading = MutableLiveData<Boolean>()
    val isViewLoading: LiveData<Boolean> = _isViewLoading

    private val _onMessageError = MutableLiveData<Any>()
    val onMessageError: LiveData<Any> = _onMessageError

    fun loadMuseums(query: String, page :Int) {
        _isViewLoading.postValue(true)
        repository.retrieveHits(query,page, object : OperationCallback {
            override fun onError(obj: Any?) {
                _isViewLoading.postValue(false)
                _onMessageError.postValue(obj)
            }

            override fun onSuccess(obj: Any?) {
                _isViewLoading.postValue(false)

                if (obj != null && obj is List<*>) {
                    if (!obj.isEmpty()) {
                        _museums.value = obj as List<Hit>
                    }
                }
            }
        })
    }

}