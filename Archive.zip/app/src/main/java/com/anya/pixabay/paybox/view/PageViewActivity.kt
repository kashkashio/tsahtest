package com.anya.pixabay.paybox.view

import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager.widget.ViewPager
import com.anya.pixabay.paybox.R
import com.anya.pixabay.paybox.model.Hit


class PageViewActivity : FragmentActivity(), ImageViewFragment.OnFragmentInteractionListener {
    override fun onFragmentInteraction(uri: Uri) {
//        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    private lateinit var mPager: ViewPager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page_view)

        // Instantiate a ViewPager and a PagerAdapter.
        mPager = findViewById(R.id.viewPager)
        mPager.setPageTransformer(true, ZoomOutPageTransformer())
        // The pager adapter, which provides the pages to the view pager widget.
        val position = getIntent().getIntExtra("currentImage",0)
        val data = getIntent().getSerializableExtra("data") as? ArrayList<Hit>

        val pagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager, position, data!!)
        mPager.adapter = pagerAdapter
        mPager.setCurrentItem(position, false)

    }

    private inner class ScreenSlidePagerAdapter(fm: FragmentManager, private val position: Int, private val data: ArrayList<Hit>) : FragmentStatePagerAdapter(fm) {
        override fun getCount(): Int = data.size
        override fun getItem(position: Int): Fragment = ImageViewFragment(data[position])
    }
}
