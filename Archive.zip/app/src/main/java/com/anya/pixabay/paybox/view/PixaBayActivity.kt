package com.anya.pixabay.paybox.view

import android.os.Bundle
import android.view.View
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.OnScrollListener
import com.anya.pixabay.paybox.R
import com.anya.pixabay.paybox.model.Hit
import com.anya.pixabay.paybox.model.PixaBayRepository
import com.anya.pixabay.paybox.viewmodel.PixaBayViewModel
import com.anya.pixabay.paybox.viewmodel.ViewModelFactory
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.layout_error.*


class PixaBayActivity : AppCompatActivity() {

    private lateinit var viewModel: PixaBayViewModel
    private lateinit var adapter: PixaBayAdapter
    private lateinit var searchView: SearchView
    private lateinit var currentQuery: String
    private var shouldClearResults: Boolean = false
    private var currentPage: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupViewModel()
        setupUI()
    }

    //ui
    private fun setupUI() {
        adapter = PixaBayAdapter(viewModel.museums.value ?: emptyList(), applicationContext)
        recyclerView.layoutManager = GridLayoutManager(this, 3)
        recyclerView.adapter = adapter

        searchView = findViewById(R.id.searchView)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }

            override fun onQueryTextSubmit(query: String): Boolean {
                currentQuery = query
                currentPage = 1
                shouldClearResults = true
                recyclerView.visibility = View.INVISIBLE
                viewModel.loadMuseums(query, 1)
                recyclerView.scrollToPosition(0)
                searchView.clearFocus()
                return false
            }

        })

        recyclerView.addOnScrollListener(object : OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                if (!recyclerView.canScrollVertically(1)) {
                    currentPage++
                    shouldClearResults = false
                    viewModel.loadMuseums(currentQuery,currentPage)
                }
            }

            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
            }
        })
    }

    private fun setupViewModel() {
        viewModel = ViewModelProviders.of(this, ViewModelFactory(PixaBayRepository()))
            .get(PixaBayViewModel::class.java)
        viewModel.museums.observe(this, renderMuseums)
        viewModel.isViewLoading.observe(this, isViewLoadingObserver)
        viewModel.onMessageError.observe(this, onMessageErrorObserver)
    }

    //observers
    private val renderMuseums = Observer<List<Hit>> {
        layoutError.visibility = View.GONE
        recyclerView.visibility = View.VISIBLE
        adapter.update(it, shouldClearResults)
        recyclerView.visibility = View.VISIBLE
    }

    private val isViewLoadingObserver = Observer<Boolean> {
        val visibility = if (it) View.VISIBLE else View.GONE
        progressBar.visibility = visibility
        layoutError.visibility = View.GONE
    }

    private val onMessageErrorObserver = Observer<Any> {
        layoutError.visibility = View.VISIBLE
        recyclerView.visibility = View.GONE
        textViewError.text = "Error $it"
    }

    override fun onResume() {
        super.onResume()
    }

}
