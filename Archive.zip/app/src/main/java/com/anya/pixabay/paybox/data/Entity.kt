package com.anya.pixabay.paybox.data

import com.anya.pixabay.paybox.model.Hit

data class ImagesResponse(val totalHits: Int?, val hits: List<Hit>?, val total: String?) {
    fun isSuccess(): Boolean = (hits?.size != 0)
}