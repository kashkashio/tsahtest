package com.anya.pixabay.paybox.model

import com.anya.pixabay.paybox.data.OperationCallback

interface PixaBayDataSource {

    fun retrieveHits(query: String, page:Int, callback: OperationCallback)
    fun cancel()
}