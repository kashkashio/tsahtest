package com.anya.pixabay.paybox.view

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.anya.pixabay.paybox.R
import com.anya.pixabay.paybox.model.Hit
import java.io.Serializable

class PixaBayAdapter(
    private var hits: List<Hit>,
    context: Context
) :
    RecyclerView.Adapter<PixaBayAdapter.MViewHolder>() {
    private val mContext = context
    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): MViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.row_image, parent, false)
//        view.setOnClickListener()

        return MViewHolder(view)
    }

    override fun onBindViewHolder(vh: MViewHolder, position: Int) {
        val museum = hits[position]

        vh.view.setOnClickListener{
            val intent = Intent(it.context, PageViewActivity::class.java).apply {
                putExtra("currentImage",position)
                putExtra("data",hits as Serializable)
            }
            it.context.startActivity(intent)
        }

        vh.textViewName.text = museum.user
        vh.likesCounter.text = museum.likes.toString()
        Glide.with(vh.imageView.context).load(museum.previewURL).into(vh.imageView)
    }

    override fun getItemCount(): Int {
        return hits.size
    }

    fun update(data: List<Hit>, shouldResetResults: Boolean) {
        if (shouldResetResults) {
            hits = data
        } else {
            hits += data
        }

        notifyDataSetChanged()
    }

    class MViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        val textViewName: TextView = view.findViewById(R.id.textViewName)
        val imageView: ImageView = view.findViewById(R.id.imageView)
        val likesCounter: TextView = view.findViewById(R.id.likesCounter)
    }
}