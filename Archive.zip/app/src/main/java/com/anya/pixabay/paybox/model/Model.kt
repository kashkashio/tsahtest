package com.anya.pixabay.paybox.model

import java.io.Serializable

/**
 * @author : Eduardo Medina
 * @since : 11/17/18
 * @see : https://developer.android.com/index.html
 */

data class Hit(
    val previewURL: String,
    val webformatURL: String,
    val tags: String,
    val likes: Int,
    val user: String
) : Serializable