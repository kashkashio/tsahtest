package com.anya.pixabay.paybox.model

import android.util.Log
import com.anya.pixabay.paybox.data.ApiClient
import com.anya.pixabay.paybox.data.ImagesResponse
import com.anya.pixabay.paybox.data.OperationCallback
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

const val TAG = "CONSOLE"

class PixaBayRepository : PixaBayDataSource {

    private var call: Call<ImagesResponse>? = null

    override fun retrieveHits(query: String, page: Int, callback: OperationCallback) {
        call = ApiClient.build()?.images(query, "14944757-a420690dd13a3fde3eeb40839", page, 21)
        call?.enqueue(object : Callback<ImagesResponse> {
            override fun onFailure(call: Call<ImagesResponse>, t: Throwable) {
                callback.onError(t.message)
            }

            override fun onResponse(
                call: Call<ImagesResponse>,
                response: Response<ImagesResponse>
            ) {
                response?.body()?.let {
                    if (response.isSuccessful && (it.isSuccess())) {
                        Log.v(TAG, "data ${it.hits}")
                        callback.onSuccess(it.hits)
                    } else {
                        callback.onError("")
                    }
                }
            }
        })
    }

    override fun cancel() {
        call?.let {
            it.cancel()
        }
    }
}