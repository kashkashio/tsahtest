package com.anya.pixabay.paybox.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.anya.pixabay.paybox.model.PixaBayDataSource

class ViewModelFactory(private val repository:PixaBayDataSource):ViewModelProvider.Factory {

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return PixaBayViewModel(repository) as T
    }
}